package TaskTest.library;

import java.io.Serializable;

public class Shelf implements Serializable {
    private String idShelf;

    private int idFloor;

    public void setIdShelf(String idShelf) {
        this.idShelf = idShelf;
    }

    public String getIdShelf() {
        return idShelf;
    }

    public void setIdFloor(int idFloor) {
        this.idFloor = idFloor;
    }

    public int getIdFloor() {
        return idFloor;
    }

    @Override
    public String toString() {
        return idShelf + " " + idFloor;
    }
}
