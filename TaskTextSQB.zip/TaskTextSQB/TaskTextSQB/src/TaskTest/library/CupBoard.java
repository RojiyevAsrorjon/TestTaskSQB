package TaskTest.library;

import TaskTest.Data.Book;

import java.io.Serializable;

public class CupBoard implements Serializable {
    private int idCupBoard;

    private String idShelf;


    public void setIdCupBoard(int idCupBoard) {
        this.idCupBoard = idCupBoard;
    }

    public int getIdCupBoard() {
        return idCupBoard;
    }

    public void setIdShelf(String idShelf) {
        this.idShelf = idShelf;
    }
    public String getIdShelf() {
        return idShelf;
    }

    @Override
    public String toString() {
        return idCupBoard + " " + idShelf;
    }
}
