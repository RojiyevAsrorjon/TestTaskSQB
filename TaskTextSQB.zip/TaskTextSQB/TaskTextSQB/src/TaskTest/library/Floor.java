package TaskTest.library;

import java.io.Serializable;

public class Floor implements Serializable {
    private int idFloor;
    private String floorName;
    private int idLibrary;

    public void  setLibraryId(int idLibrary) {
        this.idLibrary = idLibrary;
    }

    public int getIdLibrary() { return idLibrary; }

    public void setIdFloor(int idFloor) {
        this.idFloor = idFloor;
    }

    public int getIdFloor() {
        return idFloor;
    }

    public void setFloorName(String floorName) {
        this.floorName = floorName;
    }

    public String getFloorName() {
        return floorName;
    }

    @Override
    public String toString() {
        return idFloor + " " + floorName;
    }
}
