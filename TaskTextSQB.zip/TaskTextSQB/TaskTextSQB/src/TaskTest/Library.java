package TaskTest;

import TaskTest.Data.Book;
import TaskTest.library.CupBoard;
import TaskTest.library.Floor;
import TaskTest.library.Shelf;

import java.io.*;

import java.util.*;


public class Library implements Serializable {
    static String bookTextFileName = "books.txt";
    static String cupBoardTextFileName = "cupboards.txt";
    static String shelfTextFileName = "shelves.txt";
    static String floorTextFileName = "floors.txt";

    public static void main(String[] args) {
        createFiles();
        Book book = new Book("Karim", "Karim");
        List<Book> books = readFromFile(bookTextFileName);
        int idFloor = 1;
        String idShelf = "A1";
        int idCupBoard = 3;
        isAvailableFloor(readFromFloorTxt(floorTextFileName), idFloor);
        isAvailableShelf(readFromShelfTxt(), idShelf, idFloor);
        isAvailableCupBoard(readFromCupBoardTxt(), idCupBoard, idShelf);
        addBook(idCupBoard, books, book);
        books = readFromFile(bookTextFileName);
        for (Book b : books) {
            b.showInfo();
        }
        System.out.println("----------------------");
        List<Floor> floors = readFromFloorTxt(floorTextFileName);
        for (Floor f : floors) {
            System.out.println(f);
        }

        if (contains(2)) {
            System.out.println("Available");
        }

        System.out.println("______________________");
        getBooks("A1");
    }

    private String getShelf(Book book) {
        List<CupBoard> cupBoards = readFromCupBoardTxt();
        for (CupBoard c : cupBoards) {
            if (c.getIdCupBoard() == book.getIdCupBoard()) {
                return c.getIdShelf();
            }
        }
        return null;
    }

    private int getCupBoard(Book book) {
        return book.getIdCupBoard();
    }

    private int getBook(String author, String name) {
        List<Book> books = readFromFile(bookTextFileName);
        for (Book b : books) {
            if (b.getAuthor().equals(author) && b.getName().equals(name)) {
                return b.getIdBook();
            }
        }
        return -1;
    }

    private int getFloor(Book book) {
        List<CupBoard> cupBoards = readFromCupBoardTxt();
        String idShelf = " ";
        for (CupBoard c : cupBoards) {
            if (c.getIdCupBoard() == book.getIdCupBoard()) {
                idShelf = c.getIdShelf();
            }
        }
        List<Shelf> shelves = readFromShelfTxt();
        for (Shelf s : shelves) {
            if (s.getIdShelf().equals(idShelf)) {
                return s.getIdFloor();
            }
        }
        return -1;
    }

    private static void addBook(int idCupBoard, List<Book> books, Book book) {
        int count = 0;
        for (Book b : books) {
            if(b.getIdCupBoard() == idCupBoard) {
                count++;
            }
        }
        if (count < 10) {
            book.setIdBook(books.size()-1);
            book.setIdCupBoard(idCupBoard);
            writeToFile(bookTextFileName, book);
            System.out.println("Book is added");
        } else {
            System.out.println("No space in cupBoard");
        }
    }

    private static boolean contains(int idCupBoard) {
        List<Book> books = readFromFile(bookTextFileName);
        for (Book b : books) {
            if (b.getIdCupBoard() == idCupBoard) {}
            return true;
        }
        return false;
    }

    private static void getBooks(String idShelf) {
        List<Book> books = readFromFile(bookTextFileName);
        List<CupBoard> cupBoards = readFromCupBoardTxt();
        boolean bool = true;
        for (CupBoard c : cupBoards) {
            if (c.getIdShelf().equals(idShelf)) {
                for (Book b : books) {
                    if (b.getIdCupBoard() == c.getIdCupBoard()) {
                        b.showInfo();
                        bool = false;
                    }
                }
            }
        }
        if (bool) {
            System.out.println("No any book");
        }
    }

    private static void createFiles() {
        createFile(bookTextFileName);
        createFile(cupBoardTextFileName);
        createFile(shelfTextFileName);
        createFile(floorTextFileName);
    }


    private static void isAvailableCupBoard(List<CupBoard> cupBoards, int idCupBoard, String idShelf) {
        for (CupBoard c : cupBoards) {
            if (c != null && c.getIdCupBoard() == idCupBoard) {
                return;
            }
        }
        CupBoard cupBoard = new CupBoard();
        cupBoard.setIdCupBoard(idCupBoard);
        cupBoard.setIdShelf(idShelf);
        writeToCupBoardTxt(cupBoard);
    }

    private static void writeToCupBoardTxt(CupBoard cupBoard) {
        try {
            FileWriter fileWriter = new FileWriter(cupBoardTextFileName, true);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.println(cupBoard.toString());
            printWriter.close();
        } catch (IOException e) {
            System.out.println("Error!");
        }
    }

    private static void isAvailableShelf(List<Shelf> shelves, String idShelf, int idFloor) {
        for (Shelf s : shelves) {
            if (s != null && s.getIdShelf().equals(idShelf)) {
                return;
            }
        }
        Shelf shelf = new Shelf();
        shelf.setIdShelf(idShelf);
        shelf.setIdFloor(idFloor);
        writeToShelfTxt(shelf);
    }

    private static ArrayList<CupBoard> readFromCupBoardTxt() {
        ArrayList<CupBoard> cupBoards = new ArrayList<>();
        try {
            File file = new File(cupBoardTextFileName);
            if (file.canRead()) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    int idCupBoard = Integer.parseInt(scanner.next());
                    String idShelf = scanner.next();
                    CupBoard cupBoard = new CupBoard();
                    cupBoard.setIdCupBoard(idCupBoard);
                    cupBoard.setIdShelf(idShelf);
                    cupBoards.add(cupBoard);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error!");
        }
        return cupBoards;
    }
    private static void writeToShelfTxt(Shelf shelf) {

        try {
            FileWriter fw = new FileWriter(shelfTextFileName, true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println(shelf.toString());
            pw.close();
        } catch (IOException e) {
            System.out.println("Error!");
        }
    }


    private static ArrayList<Shelf> readFromShelfTxt() {
        ArrayList<Shelf> shelves = new ArrayList<>();
        try {
            File file = new File(shelfTextFileName);
            if (file.canRead()) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    String idShelf = scanner.next();
                    int idFloor = Integer.parseInt(scanner.next());
                    Shelf shelf = new Shelf();
                    shelf.setIdShelf(idShelf);
                    shelf.setIdFloor(idFloor);
                    shelves.add(shelf);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error!");
        }
        return shelves;
    }

    private static ArrayList<Floor> readFromFloorTxt(String fileName) {
        ArrayList<Floor> floors = new ArrayList<>();
        try {
            File file = new File(fileName);
            if(file.canRead()) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNext()) {
                    int idFloor = Integer.parseInt(scanner.next());
                    String nameFloor = scanner.next();
                    Floor floor = new Floor();
                    floor.setFloorName(nameFloor);
                    floor.setIdFloor(idFloor);
                    floors.add(floor);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return floors;
    }

    private static void writeToFloorTxt(Floor floor) {
        try {
            FileWriter fw = new FileWriter(floorTextFileName, true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println(floor.toString());
            pw.close();
        } catch (IOException e) {
            System.out.println("Error!");
        }
    }
    private static void isAvailableFloor(List<Floor> floors, int idFloor) {
        for (Floor floor : floors) {
            if (floor!=null && floor.getIdFloor()==idFloor) {
                return;
            }
        }
        Floor floor = new Floor();
        floor.setIdFloor(idFloor);
        floor.setFloorName(idFloor+"-etaj");
        writeToFloorTxt(floor);
    }

    public static void writeToFile(String fileName, Book book) {
        try {
            FileWriter fw = new FileWriter(fileName,true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println(book.toString());
            pw.close();
        } catch (IOException e) {
            System.out.println("Error!");
        }
    }

    private static ArrayList<Book> readFromFile(String filename) {
        ArrayList<Book> books = new ArrayList<>();
        try {
            File file = new File(filename);
                if (file.canRead()) {
                    Scanner scanner = new Scanner(file);
                    while (scanner.hasNext()) {
                        String name = scanner.next();
                        String author = scanner.next();
                        String idCupBoard = scanner.next();
                        Book book = new Book(name, author, Integer.parseInt(idCupBoard));
                        books.add(book);
                    }

                }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return books;
    }

    public static void createFile(String name) {
        try {
            File file = new File(name);
            if(!file.exists()) {
                file.createNewFile();
            }

        } catch (IOException e) {
            System.out.println("Error!");
        }
    }

}
