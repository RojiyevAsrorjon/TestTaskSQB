package TaskTest.Data;

import java.io.Serializable;

public class Book implements Serializable {
    private String name;

    private String author;

    private int idCupBoard;

    private int idBook;

    public Book(String name, String author) {
        this.name = name;
        this.author = author;
    }

    public Book(String name, String author, int idCupBoard) {
        this.name = name;
        this.author = author;
        this.idCupBoard = idCupBoard;
    }
    public void setIdBook(int idBook) { this.idBook = idBook; }

    public int getIdBook() { return idBook; }

    public void setIdCupBoard(int idCupBoard) {
        this.idCupBoard = idCupBoard;
    }

    public int getIdCupBoard() {
        return idCupBoard;
    }

    public boolean equals(Book book) {
        return book.getName().equals(this.name) && book.getAuthor().equals(this.author);
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }


    @Override
    public String toString() {
        return  name+" "+author+" "+idCupBoard;
    }

    public void showInfo() {
        System.out.println("Name: "+name+" Author: "+author+" IdCupBoard: "+idCupBoard);
    }
}
